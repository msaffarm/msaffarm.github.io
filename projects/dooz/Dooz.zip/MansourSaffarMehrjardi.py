# Imports
import socket
import sys
from sys import maxsize as inf
# Auxiliary Functions

def count_occupied_cells(state): # counts number of cells which are occupided by playes
    counter = 0
    for i in range(9) :
        if state[i] != FREE_SIGN:
            counter += 1
    
    return counter


def add_children(state,maxormin):
 # This function adds player to game board instead of moving it.
 # In early stages of game we just add players 
    if maxormin == 'max' :
        char = MY_NUMBER
    elif maxormin == 'min' : 
        char = ENEMY_NUMBER
    freepos = find_pos(state, FREE_SIGN)
    state_list = []
    for i in freepos :
        t = list(state)
        t[i] = char
        t = ''.join(t)
        state_list.append(t)
    return state_list    


def has_I_won(state): # Have I won the game?!! I know it's name should be Have_I_won !!
    mypos = find_pos(state, MY_NUMBER)
    if mypos in WIN_LIST :
        return True
    else :
        return False

    
def has_enemy_won(state): # Has the enemy won the game?!
    enemypos = find_pos(state, ENEMY_NUMBER)
    if enemypos in WIN_LIST :
        return True
    else :
        return False


def find_pos(state,char): # Finds the index of all cells with char in them
    l = []
    for i,c in enumerate(state):
        if c == char:
            l.append(i)
    return l


def eval_pos(pos): 
 # counts number of char pairs in WIN_LIST.
 # The heuristic is that the more the pairs are, the better that state is.
    fval = 0
    l = len(pos)
    for i in range(l):
        s = set(list([pos[i-1],pos[i]]))
        for x in WIN_LIST:
            if s.issubset(x):
                fval+=1
    return fval


def eval_state(state):
 # evaluates state according to numbers of player pairs. Number of enemy pairs are subtracted from
 # number of my pairs. For terminal states evaluation returns -inf for losing and inf for winning 
    mypos = find_pos(state, MY_NUMBER)
    enemypos = find_pos(state, ENEMY_NUMBER)
    ## check whether me or enemy is in win position
    if mypos in WIN_LIST:
        return inf
    if enemypos in WIN_LIST:
        return -inf
    ## determine state value according to evaluation function
    ## evaluation function checks for possible pairs of same player in WIN_LIST
    myval = eval_pos(mypos)
    enemyval = eval_pos(enemypos)
    return myval-enemyval


def create_state_list(state,char): 
 # creates the list of states possible moves by moving the min or max player
    pos = find_pos(state,char)
    state_list = []
    for i in pos:
        adj = ADJACENCY_LIST[i]
        for neigh in adj:
            if state[neigh] == FREE_SIGN:
                t = list(state)
                t[neigh] = char # put char in position
                t[i] = FREE_SIGN # empty current postition
                t = ''.join(t)
                state_list.append(t)
    return state_list


def create_possible_states(state,maxormin):
 # If player is max then my playes are moved in next state, so this function creates all possible 
 # descendents of current state. If player is min player then his players are moved.
    if maxormin == 'max':
        states = create_state_list(state,MY_NUMBER)
    elif maxormin == 'min':
        states = create_state_list(state,ENEMY_NUMBER)
    return states


class node():
    '''Class node represents each state of dooz game. depth is node depth , state 
    represents game board state and maxormin means whether node is max node or min 
    node. initial val of each node is first set to -inf or inf according to its 
    maxormin value BUT is updated during minmax_with_alphabeta algorithm.
    children is the list of all children of this node which are only 1 layer above him.
    make_children creates children by moving players BUT make_children_just_adding creates 
    children by adding players to game board and is for initial steps of game.
    eval function just evaluates node's state
    '''
    def __init__(self,depth,state):
        self.depth = depth
        self.state = state
        self.maxormin = 'max' if ( (self.depth) % (2) == 0 ) else 'min'
        self.val = -inf if self.maxormin == 'max' else inf 
        self.children = []
    
    def make_children(self):# make children!!
        if self.depth <= (DEPTH_LIMIT-1):
            state_list = create_possible_states(self.state,self.maxormin)
            for x in state_list:
                self.children.append(node(self.depth+1,x))
        return self.children 
    
    def make_children_just_adding(self):# for initial steps of game
        if self.depth <= (DEPTH_LIMIT-1):
            state_list = add_children(self.state,self.maxormin)
            for x in state_list:
                self.children.append(node(self.depth+1,x))
        return self.children
     
    def eval(self):
        return eval_state(self.state)


def minmax_with_alphabeta(node,depth,maxormin,alpha,beta,first_steps):
 # recursive minimax algorithm implementaion with alpha-bata pruning.

    # NOTE: first_layer is the list of all nodes in first layer (depth =1) of tree which means
    # they are the children of root node. we need to know their value which is assigned to them in 
    # minimax algorithm to decide which way to go in next move.


    # if we have reached maximum depth allowed (DEPTH_LIMIT) or we have reaches a terminal state, then
    # return it's evaluation number
    if depth == DEPTH_LIMIT or has_I_won(node.state) or has_enemy_won(node.state) :
        if depth == 1:
            first_layer.append((node.eval(),node.state))
        return node.eval()
    
    # if player is max then choose maximum value of his descendents. 
    if maxormin == 'max':
        node.val = -inf
        if not first_steps : #if we are in first steps of game then just add players otherwise make them
            node_children = node.make_children()
        else :
            node_children = node.make_children_just_adding()
        for child in node_children:
            node.val = max(node.val,minmax_with_alphabeta(child, depth+1,'min',alpha,beta,first_steps))
            alpha = max(alpha,node.val)
            if beta <= alpha : # pruning if we have already found a greater value
                break
        if depth == 1:
            first_layer.append((node.val,node.state))
        return node.val
   
    # if player is min then choode minimum value of his descendents.
    elif maxormin == 'min':
        node.val = inf
        if not first_steps : #if we are in first steps of game then just add players otherwise make them
            node_children = node.make_children()
        else :
            node_children = node.make_children_just_adding()
        for child in node_children:
            node.val = min(node.val,minmax_with_alphabeta(child, depth+1,'max',alpha,beta,first_steps))
            beta = min(beta,node.val)
            if beta <= alpha :  # pruning if we have already found a more little value
                break
        if depth == 1:
            first_layer.append((node.val,node.state))
        return node.val


# Constants
FREE_SIGN = '-'
ADJACENCY_LIST = [[1,3,4],[0,2,4],[1,4,5],[0,4,6],[0,1,2,3,5,6,7,8],[2,4,8],[3,4,7],[4,6,8],[4,5,7]]
HOST_NAME = socket.gethostname()
MY_NUMBER = sys.argv[1]
# MY_NUMBER = '1'
ENEMY_NUMBER = '2' if MY_NUMBER == '1' else '1'
PORT_NUMBER = 2000 + int(MY_NUMBER)
BUFFER_SIZE = 1024
GAME_OVER_MESSAGE = "GameOver"
WIN_LIST = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]# all terminal pairs


# Create Welcoming TCP Socket
welcoming_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
welcoming_socket.bind((HOST_NAME,PORT_NUMBER))
welcoming_socket.listen(1)
(agent_socket,address) = welcoming_socket.accept()


# Start the game
my_step = 0
game_state = agent_socket.recv(BUFFER_SIZE)

while game_state != GAME_OVER_MESSAGE :

    if my_step <= 2 :
        # DEPTH_LIMIT is chosen adaptively so as to all possible permutions of players is checked
        DEPTH_LIMIT = 6 - count_occupied_cells(game_state)
        root = node(0,game_state)
        alpha = -inf
        beta = inf
        first_layer = []
        t = minmax_with_alphabeta(root, 0, 'max', alpha, beta,True)
        for x in first_layer :
            if x[0]== t:
                best_move = x[1]
                break
        for i in range(9):
            if game_state[i] == FREE_SIGN and best_move[i] == MY_NUMBER :
                x = i
        next_move = str(x)
        
    else :
        # DEPTH_LIMIT is chosen 9. THis value was chosen arbitararily so as to satisfy time(MAX 1 second)
        # and computation constraints
        DEPTH_LIMIT = 9
        root = node(0,game_state)
        alpha = -inf
        beta = inf
        first_layer = []
        t = minmax_with_alphabeta(root, 0, 'max', alpha, beta,False)
        for x in first_layer :
            if x[0]== t:
                best_move = x[1]
                break
        for i in range(9):
            if game_state[i] == FREE_SIGN and best_move[i] == MY_NUMBER :
                y = i
            elif game_state[i] == MY_NUMBER and best_move[i] == FREE_SIGN :
                x = i
        next_move = str(x) + str(y)
        
    agent_socket.send(str(next_move))
    my_step += 1
    game_state = agent_socket.recv(BUFFER_SIZE)
    
agent_socket.close()







